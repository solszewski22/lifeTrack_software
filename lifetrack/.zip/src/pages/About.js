import React from 'react'

function About() {
    return (
        <h1 class="container">About</h1>
    );
}

export default About;