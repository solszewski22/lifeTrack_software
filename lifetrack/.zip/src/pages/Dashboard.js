import React from 'react'
import {Link} from 'react-router-dom'

function Dashboard(props) {
    function onRowClick(e){
        e.preventDefault();

        const goal = {
            title: e.target.title.value,
            description: e.target.title.value,
            status: e.target.status.value
        }
        props.onGetGoal(goal);
    }
    
    return (
        <div class="container">
            <hr/>
            <Link to="/createGoal" type="button" class="btn btn-success">Add</Link>
            <button type="button" class="btn btn-danger">Remove</button>
            <table class="table table-striped table-hover">
            <thead>
                <tr>
                <th scope="col">Title</th>
                <th scope="col">Description</th>
                <th scope="col">Status</th>
                </tr>
            </thead>
            <tbody onClick={onRowClick}>
            {props.goals.map((goal) => { 
                    return ( 
                        <tr key={goal.id}> 
                            <td id="title">{goal.title}</td> 
                            <td id="description">{goal.description}</td>
                            <td id="status">{goal.status}</td>                                                     
                        </tr> 
                    ); 
                })} 
            </tbody>
            </table>
        </div>
    )
};

export default Dashboard;